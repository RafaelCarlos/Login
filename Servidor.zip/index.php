<?php

$usuario = $_POST['usuario'];
$senha = $_POST['senha'];


$conexao = mysql_connect('localhost','root','');
mysql_select_db('android', $conexao);

$sql = "select * from usuarios where usuario ='$usuario' and senha ='$senha' ";
$result = mysql_query($sql) or die("Erro: " . mysql_error());

if (mysql_num_rows ($result)>0)

{
	echo "1";
}
else{
	echo "0";
} 
	

?>