<?php

$conexao = mysql_connect('localhost','root','');
mysql_select_db('android', $conexao);

$sql = "select * from usuarios";
$result = mysql_query($sql) or die("Erro: " . mysql_error());

while($linha = mysql_fetch_object($result))
{
	echo $linha->usuario ;
	
}


if (mysql_num_rows ($result)>0)

{
	echo "1";
}
else{
	echo "0";
} 
	

?>