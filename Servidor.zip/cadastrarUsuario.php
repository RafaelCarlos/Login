<?php

$usuario = $_POST['usuario'];
$senha = $_POST['senha'];


$conexao = mysql_connect('localhost','root','');
mysql_select_db('android', $conexao);

$sql = "insert into usuarios (usuario, senha) values ('$usuario', '$senha')";
$result = mysql_query($sql) or die("Erro: " . mysql_error());

if(!$result )
	echo "1";

else "0";
	

?>